export default {
  BgImage: require("../assets/images/bg-image.jpg"),
  Vineyard: require("../assets/images/vineyard.jpg"),
  Wine3: require("../assets/images/wine-3.jpg"),
  Wine2: require("../assets/images/wine-2.jpg"),
  Wine1: require("../assets/images/wine-1.jpg"),
  Wine4: require("../assets/images/wine-4.jpg")
}
