import React from "react"
import { StatusBar, StyleSheet } from "react-native"
import { draftbit as screenTheme } from "../config/Themes"
import { withTheme, ScreenContainer } from "@draftbit/ui"

class HomeScreen extends React.Component {
  constructor(props) {
    super(props)
    StatusBar.setBarStyle("light-content")

    this.state = {
      theme: Object.assign(props.theme, screenTheme)
    }
  }

  render() {
    const { theme } = this.state

    return <ScreenContainer hasSafeArea={false} scrollable={true} style={styles.Root_n4n} />
  }
}

const styles = StyleSheet.create({})

export default withTheme(HomeScreen)
