import React from "react"
import { StatusBar, StyleSheet, Text, FlatList } from "react-native"
import { draftbit_dark as screenTheme } from "../config/Themes"
import { withTheme, ScreenContainer, Container, CardInline } from "@draftbit/ui"

class NewScreen extends React.Component {
  constructor(props) {
    super(props)
    StatusBar.setBarStyle("light-content")

    this.state = {
      theme: Object.assign(props.theme, screenTheme)
    }
  }

  render() {
    const { theme } = this.state

    return (
      <ScreenContainer hasSafeArea={true} scrollable={false} style={styles.Root_ne2}>
        <Container style={styles.Container_ng7} elevation={0} useThemeGutterPadding={true}>
          <Text
            style={[
              styles.Text_nbp,
              theme.typography.headline1,
              {
                color: theme.colors.strong
              }
            ]}
          >
            Home
          </Text>
        </Container>
        <FlatList
          style={styles.FlatList_n3q}
          horizontal={true}
          data={[]}
          keyExtractor={(_item, idx) => idx.toString()}
          onRefresh={() => {
            this.setState({ refreshing: true })
            refetch()
          }}
          refreshing={this.state.refreshing || false}
          renderItem={({ item }) => (
            <CardInline
              style={styles.CardInline_nrp}
              title="Beautiful West Coast Villa"
              elevation={2}
              numColumns={3}
              aspectRatio={1.5}
              description="San Diego"
            />
          )}
          contentContainerStyle={{ paddingHorizontal: theme.spacing.gutters }}
        />
      </ScreenContainer>
    )
  }
}

const styles = StyleSheet.create({
  Text_nbp: {
    marginLeft: 10,
    marginTop: 30
  }
})

export default withTheme(NewScreen)
