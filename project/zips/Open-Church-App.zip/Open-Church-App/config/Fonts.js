export default {
  BisonBold: require("../assets/fonts/BisonBold.ttf"),
  BisonBoldItallic: require("../assets/fonts/BisonBoldItallic.ttf"),
  BisonLight: require("../assets/fonts/BisonLight.ttf"),
  BisonDemiBold: require("../assets/fonts/BisonDemiBold.ttf"),
  BisonDemiBoldItallic: require("../assets/fonts/BisonDemiBoldItallic.ttf"),
  BisonRegularItalic: require("../assets/fonts/BisonRegularItalic.ttf"),
  BisonRegular: require("../assets/fonts/BisonRegular.ttf"),
  BisonThickOutline: require("../assets/fonts/BisonThickOutline.ttf"),
  BisonLightItalic: require("../assets/fonts/BisonLightItalic.ttf"),
  BisonThickOutlineItallic: require("../assets/fonts/BisonThickOutlineItallic.ttf"),
  BisonThinOutline: require("../assets/fonts/BisonThinOutline.ttf"),
  BisonThinOutlineItallic: require("../assets/fonts/BisonThinOutlineItallic.ttf")
}
